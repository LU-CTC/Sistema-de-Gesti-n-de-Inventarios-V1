function addProductToController(name, quantity) {
    if (name === "" || quantity < 0) {
        throw new Error("Datos inválidos");
    }
    return { name, quantity };
}

module.exports = { addProductToController };
