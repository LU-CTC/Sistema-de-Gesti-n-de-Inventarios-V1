let products = [];

function addProduct() {
    let name = document.getElementById("productName").value;
    let quantity = parseInt(document.getElementById("productQuantity").value);
    if (name === "" || isNaN(quantity) || quantity < 0) {
        alert("Por favor, ingrese valores válidos.");
        return;
    }
    let product = { name: name, quantity: quantity };
    products.push(product);
    updateTable();
    clearInputs();
}

function deleteProduct(index) {
    products.splice(index, 1);
    updateTable();
}

function updateTable() {
    let tableBody = document.querySelector("#productTable tbody");
    tableBody.innerHTML = "";
    for (let i = 0; i < products.length; i++) {
        let row = `<tr>
            <td>${products[i].name}</td>
            <td>${products[i].quantity}</td>
            <td><button onclick="deleteProduct(${i})">Eliminar</button></td>
        </tr>`;
        tableBody.innerHTML += row;
    }
}

function clearInputs() {
    document.getElementById("productName").value = "";
    document.getElementById("productQuantity").value = "";
}
