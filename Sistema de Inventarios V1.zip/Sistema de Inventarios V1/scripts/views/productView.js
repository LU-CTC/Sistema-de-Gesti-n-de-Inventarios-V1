function renderTable(products) {
    let tableBody = document.querySelector("#productTable tbody");
    tableBody.innerHTML = "";
    products.forEach((product, index) => {
        tableBody.innerHTML += `
            <tr>
                <td>${product.name}</td>
                <td>${product.quantity}</td>
                <td><button onclick="deleteProduct(${index})">Eliminar</button></td>
            </tr>`;
    });
}
