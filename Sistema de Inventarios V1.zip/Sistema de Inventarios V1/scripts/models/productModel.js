function Product(name, quantity) {
    this.name = name;
    this.quantity = quantity;
}
