const { addProductToController } = require('../scripts/controllers/productController');

test('Agregar un producto válido', () => {
    const product = addProductToController('Producto A', 10);
    expect(product).toEqual({ name: 'Producto A', quantity: 10 });
});

test('Rechazar producto con datos inválidos', () => {
    expect(() => addProductToController('', -1)).toThrow('Datos inválidos');
});
